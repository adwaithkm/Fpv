
from physics import setup_physics, apply_drone_controls

def load_race_mode(app):
    print("Loading Race Mode...")
    app.load_environment("assets/race_track")
    drone = setup_physics()
    app.taskMgr.add(lambda task: drone_control_task(drone), "DroneControlTask")

def load_task_mode(app):
    print("Loading Task Mode...")
    app.load_environment("assets/task_zone")
    drone = setup_physics()
    app.taskMgr.add(lambda task: drone_control_task(drone), "DroneControlTask")

def load_free_play_mode(app):
    print("Loading Free Play Mode...")
    app.load_environment("assets/free_play_area")
    drone = setup_physics()
    app.taskMgr.add(lambda task: drone_control_task(drone), "DroneControlTask")

def drone_control_task(drone):
    keys = {"w": False, "s": False, "a": False, "d": False}
    apply_drone_controls(drone, keys)
    return Task.cont
