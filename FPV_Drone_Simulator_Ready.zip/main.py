
from flask import Flask, render_template, request
from gameplay_modes import load_race_mode, load_task_mode, load_free_play_mode

app = Flask(__name__)

@app.route("/")
def home():
    return '''
        <h1>FPV Drone Simulator</h1>
        <form action="/mode" method="post">
            <label>Select a Mode:</label><br>
            <button type="submit" name="mode" value="1">Race Mode</button><br>
            <button type="submit" name="mode" value="2">Task Mode</button><br>
            <button type="submit" name="mode" value="3">Free Play Mode</button>
        </form>
    '''

@app.route("/mode", methods=["POST"])
def mode():
    mode = request.form["mode"]
    if mode == "1":
        load_race_mode()
        return "Race Mode Loaded!"
    elif mode == "2":
        load_task_mode()
        return "Task Mode Loaded!"
    elif mode == "3":
        load_free_play_mode()
        return "Free Play Mode Loaded!"
    else:
        return "Invalid Mode!"

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
