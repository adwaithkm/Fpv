
from panda3d.core import Loader

def load_environment(app, environment_path):
    loader = Loader.getGlobalPtr()
    scene = loader.loadModel(environment_path)
    scene.reparentTo(app.render)
    scene.setScale(1.0)
    return scene
