
import pybullet as p
import pybullet_data

def setup_physics():
    p.connect(p.GUI)
    p.setAdditionalSearchPath(pybullet_data.getDataPath())
    p.setGravity(0, 0, -9.8)
    drone = p.loadURDF("assets/drone.urdf", [0, 0, 1])
    return drone

def apply_drone_controls(drone, keys):
    thrust = 0
    pitch, roll, yaw = 0, 0, 0

    if keys["w"]:
        thrust += 5
    if keys["s"]:
        thrust -= 5
    if keys["a"]:
        yaw += 0.1
    if keys["d"]:
        yaw -= 0.1

    p.applyExternalForce(drone, -1, [0, 0, thrust], [0, 0, 0], p.LINK_FRAME)
    p.stepSimulation()
