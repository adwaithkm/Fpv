
# FPV Drone Simulator

## Description
A realistic FPV drone simulator with three modes: Race, Task, and Free Play. Built using Panda3D and PyBullet for physics.

## Setup
1. Install dependencies:
   ```
   pip install panda3d pybullet numpy
   ```
2. Run the simulator:
   ```
   python main.py
   ```

## Controls
- W: Throttle Up
- S: Throttle Down
- A: Yaw Left
- D: Yaw Right
